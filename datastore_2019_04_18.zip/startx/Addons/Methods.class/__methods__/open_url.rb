#
# Description: This method is used within a button to open External URL
#
url = "http://#{$evm.root['vm'].ipaddresses[1]}" 
$evm.log(:info, "Requested URL #{url}")
$evm.root['vm'].remote_console_url = url
