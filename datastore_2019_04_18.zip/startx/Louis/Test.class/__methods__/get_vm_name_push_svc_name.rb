vm_name = $evm.root["Dialog_vm_name"]

svc_name = $evm.object
svc_name["required"] = "true"


if vm_name.empty?
	
  svc_name["value"] = ""
  
else 
  
  svc_name["value"] = "svc_#{vm_name}"
  
end 


