#
# Description: <Method description here>
#

$evm.log(:info, "Hello, World!")
exit MIQ_OK
