#
# Description: <Method description here>
#
vmname= $evm.root['dialog_vm_name']
$evm.log(:info, "The name of the VM : #{vmname}")
element = $evm.object
# required: true / false


element["value"] = vmname
