#
# service = $evm.vmdb('service').find_by_name("LAB1")

  parent_service_name = $evm.root['dialog_parent_service']
  
  parent_service = $evm.vmdb('service').find_by_name(parent_service_name)
  # 
 # $evm.log(:info, "found service #{parent_service.name}")
  if parent_service.nil?
    $evm.log(:error, "Can't find service with ID: #{parent_service_name}")
    exit MIQ_ERROR
  else
    #case $evm.root['vmdb_object_type']
   # when 'service'
   #   $evm.log(:info, "Adding Service #{$evm.root['service'].name} to #{parent_service.name}")
   #   $evm.root['service'].parent_service = parent_service
   # when 'vm'
      prov = $evm.root['miq_provision'] || $evm.root['vm'].miq_provision
      vm = prov.vm
      #
      # See if the VM is already part of a service
      #
      unless vm.service.nil?
        old_service = vm.service
        vm.remove_from_service
        if old_service.v_total_vms.zero?
          $evm.log(:info, "Old service #{old_service.name} is now empty, removing it from VMDB")
          old_service.remove_from_vmdb
        end
      end
      $evm.log(:info, "Adding VM #{vm.name} to #{parent_service.name}")
      vm.add_to_service(parent_service)
    end

 exit MIQ_OK
