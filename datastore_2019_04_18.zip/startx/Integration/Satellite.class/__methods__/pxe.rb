require 'httpclient'
require 'base64'
require 'json'
require 'uri'
require 'ipaddress'

@debug=true
class String
  def red;            "\e[31m#{self}\e[0m" end
  def green;          "\e[32m#{self}\e[0m" end
  def brown;          "\e[33m#{self}\e[0m" end
  def blue;           "\e[34m#{self}\e[0m" end
  def magenta;        "\e[35m#{self}\e[0m" end
  def cyan;           "\e[36m#{self}\e[0m" end
  def bold;           "\e[1m#{self}\e[22m" end
end
def loginfo(message)
  $evm.log(:info,message.bold) if @debug
end


def rest_send (http_verb, body, url)
  http = HTTPClient.new
  http.ssl_config.verify_mode = OpenSSL::SSL::VERIFY_NONE

  #headers = { "Accept" => "application/json",
  #  "X-IPM-Username" => @username,
  #  "X-IPM-Password" => @password
  #  }
  headers = { "Accept" => "application/json",
    "Content-Type" => "application/json",
    "Authorization" => "Basic #{@authtoken}"
    }
  
  case http_verb
    when :get
    result = JSON.parse(http.get(url, nil, headers).content)
    when :post
    result = JSON.parse(http.post(url, body, headers).content)
    
    when :delete
    result = JSON.parse(http.delete(url, nil, headers).content)
    else
    loginfo("====> ERROR : Unknown http_verb in rest_send")
  end
end


loginfo("Starting method".green)
@username = $evm.current['satellite_username']
@password = $evm.current.decrypt('satellite_password')
@authtoken = @username+":"+@password
#loginfo("The result token: #{@authtoken}".green)
@authtoken = Base64.strict_encode64(@authtoken)

loginfo("The result encoded token: #{@authtoken}".green)

url=$evm.current['satellite_uri'] 
url += '/api/hosts'
prov = $evm.root["miq_provision"]
vm = prov.vm
### Prerpare the hash to be sent to Satellite 
# Attention ! ## The Satellite does not accept Upcases or symbols in the name of the hosts 

content = '{"location_id": 2,"organization_id": 1,"host": {"name": "'
content += vm.name.to_s.downcase
content += '","location_id": 2,"organization_id": 1,"mac": "'
content += vm.mac_addresses[0].to_s
content += '","architecture_id": 1,"domain_id": 2,"puppetclass_ids": [],"operatingsystem_id": 1,"medium_id": 1,"ptable_id": 94,"compute_attributes": {"volumes_attributes": {}},"content_facet_attributes": {},"subscription_facet_attributes": {},"build": true,"managed": true,"enabled": true,"overwrite": true,"interfaces_attributes": [],"root_pass": "redhat123"}}'
content_hash = JSON.parse(content)
loginfo("content hash #{content_hash}")

result = rest_send(:post, content, url)

loginfo("#{result}".cyan)



## To Do implement VM reboot 
#
#
# TODO implement wait for installation to finish 

#
#
